// detects when you click The Magic8Ball, it activates the Function Magic8Ball
document.getElementById("Magic8BallImage").addEventListener("click", Magic8Ball)


// function that has all the code
function Magic8Ball() {
    // gets the value of the QuestionInput
    let Input = document.getElementById("QuestionInput").value;
    // The Variable RandNum, gets a random value
    let RandNum = Math.random();
    // when you don't type anything, it displays "Please Ask a question". When you ask it a question, it gives you an answer depending on what Value RandNum has.
    if (Input === "") {
        document.getElementById("AnswerOutput").innerHTML = ("Please ask a question");
    } else if (Input === "does this work?") {
        document.getElementById("AnswerOutput").innerHTML = ("Probably?")
    } else if (Input === "will this project get a good mark?") {
        document.getElementById("AnswerOutput").innerHTML = ("YES, DEFINITELY, WITHOUT A DOUBT!")
    } else if (RandNum < 0.2) {
        document.getElementById("AnswerOutput").innerHTML = ("Without a Doubt");
    } else if (RandNum < 0.4) {
        document.getElementById("AnswerOutput").innerHTML = ("As I see it, yes");
    } else if (RandNum < 0.6) {
        document.getElementById("AnswerOutput").innerHTML = ("Concentrate and ask again");
    } else if (RandNum < 0.8) {
        document.getElementById("AnswerOutput").innerHTML = ("Don't count on it");
    } else if (RandNum < 0.10) {
        document.getElementById("AnswerOutput").innerHTML = ("Outlook not so good");
    }
}